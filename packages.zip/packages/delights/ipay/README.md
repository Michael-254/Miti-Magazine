# iPay Africa Web Based Integration API

This is a PHP package for iPay Africa Web based integration. The API allows a merchant to initiate C2B transaction and
receive payments from the customers.

## Installation

Pull in the package through Composer.
```bash
composer require delights/ipay
```

Create the following variables in your .env file.
```bash
IPAY_VENDOR_ID=vendorid
IPAY_VENDOR_SECRET=vendorsecret
```

## Usage
To make a request is simple. Just initiate the `Cashier` and finalize the transaction:
```php
use Delights\Ipay\Cashier;

require "vendor/autoload.php";

$cashier = new Cashier();

$response = $cashier
    ->usingVendorId(env('IPAY_VENDOR_ID'), env('IPAY_VENDOR_SECRET'))
    ->withCallback('http://yourcallback.com')
    ->withCustomer('0722000000', 'demo@example.com', false)
    ->transact(10, 'your order id', 'your order secret');
```
The `$response` variable will hold the html response from iPay. Just render it to the page and
the process would be complete.

## Payment Channels
By default, you are able to transact with multiple channels. The package default are:
- MPesa
- Airtel Money
- Equity
- Credit Card
- Debit Card

In order to use other channels, you can call the `usingChannels()` method with a channel array.
The currently available channels are:
- Cashier::CHANNEL_MPESA
- Cashier::CHANNEL_AIRTEL
- Cashier::CHANNEL_EQUITY
- Cashier::CHANNEL_MOBILE_BANKING
- Cashier::CHANNEL_DEBIT_CARD
- Cashier::CHANNEL_CREDIT_CARD
- Cashier::CHANNEL_MKOPO_RAHISI
- Cashier::CHANNEL_SAIDA

For example:
```php
use Delights\Ipay\Cashier;

require "vendor/autoload.php";

$cashier = new Cashier();

$transactChannels = [
    Cashier::CHANNEL_MPESA,
    Cashier::CHANNEL_AIRTEL,
];

$response = $cashier
    ->usingChannels($transactChannels)
    ->usingVendorId('your vendor id', 'your vendor secret')
    ->withCallback('http://yourcallback.com')
    ->withCustomer('0722000000', 'demo@example.com', false)
    ->transact(10, 'your order id', 'your order secret');
```
