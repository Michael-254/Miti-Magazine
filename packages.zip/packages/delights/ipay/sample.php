<?php

use Delights\Ipay\Cashier;

require "vendor/autoload.php";

$cashier = new Cashier();

$transactChannels = [
    Cashier::CHANNEL_MPESA,
    Cashier::CHANNEL_AIRTEL,
];

$response = $cashier
    ->usingChannels($transactChannels)
    ->usingVendorId(env('IPAY_VENDOR_ID'), env('IPAY_VENDOR_SECRET'))
    ->withCallback('http://yourcallback.com')
    ->withCustomer('0722000000', 'demo@example.com', false)
    ->transact(10, 'your order id', 'your order secret');

echo $response;
