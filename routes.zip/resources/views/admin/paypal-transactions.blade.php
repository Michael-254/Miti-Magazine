@extends('layouts.app')

@section('content')

@livewire('admin-paypal')

@endsection