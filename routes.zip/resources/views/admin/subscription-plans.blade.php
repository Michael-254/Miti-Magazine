@extends('layouts.app')

@section('content')

@livewire('manage-plans')

@endsection