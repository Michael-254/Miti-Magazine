<div class="bg-white flex justify-center items-center p-1 border-4 border-green-500">
     <img class="w-16 h-16" src="{{asset('storage/logo.png')}}">
</div>