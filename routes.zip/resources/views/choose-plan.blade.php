@extends('layouts.main')
    
@section('content')

@livewire('homepage-plans')

@endsection