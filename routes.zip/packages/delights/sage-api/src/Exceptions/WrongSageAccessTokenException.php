<?php

namespace Delights\SageApi\Exceptions;

class WrongSageAccessTokenException extends \Exception
{
}
