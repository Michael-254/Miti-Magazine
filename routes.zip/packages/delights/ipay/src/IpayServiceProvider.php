<?php

/**
 * @Author: Evans Wanguba
 * @Date:   2020-01-10 14:02:33
 * @Last Modified by:   Evans Wanguba
 * @Last Modified time: 2016-02-16 17:15:18
 */

namespace Delights\Ipay;

use Illuminate\Support\ServiceProvider;
use Delights\Ipay\Cashier;

class IpayServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(Cashier::class, function () {
            return new Cashier();
        });
    }
}
