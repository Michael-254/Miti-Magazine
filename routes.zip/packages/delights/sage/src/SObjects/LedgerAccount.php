<?php

namespace Delights\Sage\SObjects;

use Delights\Sage\SObject;

class LedgerAccount extends SObject
{
    const RESOURCE_NAME = "ledger_accounts";
}
