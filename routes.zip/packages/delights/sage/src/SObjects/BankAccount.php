<?php

namespace Delights\Sage\SObjects;

use Delights\Sage\SObject;

class BankAccount extends SObject
{
    const RESOURCE_NAME = "bank_accounts";
}
